package fr.univ.lyon1.mastermind;

public enum Peg {
	RED,
	GREEN,
	BLUE,
	YELLOW,
	ORANGE,
	PURPLE
}
