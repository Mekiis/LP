//
//  SiteRateKit.h
//  SiteRateKit
//
//  Created by iem on 07/05/2015.
//  Copyright (c) 2015 iem. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SiteRateKit.
FOUNDATION_EXPORT double SiteRateKitVersionNumber;

//! Project version string for SiteRateKit.
FOUNDATION_EXPORT const unsigned char SiteRateKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SiteRateKit/PublicHeader.h>


