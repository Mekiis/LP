//
//  PlaceTypeTableViewCell.swift
//  Visits
//
//  Created by iem on 07/05/2015.
//  Copyright (c) 2015 iem. All rights reserved.
//

import UIKit
import SiteRateKit

class PlaceTypeTableViewCell: UITableViewCell {

    @IBOutlet var title: UILabel!
    @IBOutlet var subTitle: UILabel!
    @IBOutlet var quantity: SiteTileView!

    
}
