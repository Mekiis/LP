//
//  PinPlace.swift
//  Visits
//
//  Created by iem on 09/04/2015.
//  Copyright (c) 2015 iem. All rights reserved.
//

import Foundation
import MapKit

class PinPlace : MKPointAnnotation {
    var place : Place?
}