package banand.lionel.com.tpandroid.Items;

/**
 * Created by lionel on 30/09/14.
 */
public class MenuMediasItem {
    public int mIcon;
    public String mName;

    public MenuMediasItem(int icon, String name) {
        mIcon = icon;
        mName = name;
    }
}
