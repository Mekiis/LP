package banand.lionel.com.tpandroid.DAO.Objects;

/**
 * Created by lionel on 06/10/14.
 */
public class ImageObject {
    public String name;
    public int versionCode;
    public String path;
}
